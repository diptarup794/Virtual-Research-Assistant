// Initialize AOS animation library
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease-out-cubic',
        once: false,
        mirror: true,
        anchorPlacement: 'top-bottom'
    });
});

// DOM Elements
const form = document.getElementById('search-form');
const queryInput = document.getElementById('query');
const resultsDiv = document.getElementById('results');
const resultsSection = document.getElementById('results-section');
const loadingDiv = document.getElementById('loading');
const errorDiv = document.getElementById('error-message');
const progressBar = document.querySelector('.progress-bar');

// Form submission handler
form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const query = queryInput.value.trim();
    if (!query) return;

    // Clear previous results and errors
    resultsDiv.innerHTML = '';
    errorDiv.style.display = 'none';
    errorDiv.textContent = '';
    resultsSection.style.display = 'none';
    
    // Show loading with animated progress
    loadingDiv.style.display = 'block';
    animateProgress();

    try {
        const response = await fetch('/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query: query }),
        });

        // Hide loading
        loadingDiv.style.display = 'none';

        if (!response.ok) {
            let errorMsg = `Error: ${response.status}`;
            try {
                const errorData = await response.json();
                errorMsg = errorData.error || errorMsg;
            } catch (e) {
                // If response isn't JSON
            }
            throw new Error(errorMsg);
        }

        const data = await response.json();

        if (data.error) {
            throw new Error(data.error);
        }

        // Display results
        if (data.papers && data.papers.length > 0) {
            resultsSection.style.display = 'block';
            
            data.papers.forEach((paper, index) => {
                const paperCard = createPaperCard(paper, index);
                resultsDiv.appendChild(paperCard);
                
                // Add staggered animation
                setTimeout(() => {
                    paperCard.classList.add('fade-in');
                }, index * 150);
            });
            
            // Scroll to results
            setTimeout(() => {
                resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 300);
        } else {
            showError(data.message || 'No papers found for this topic.');
        }

    } catch (error) {
        console.error('Search failed:', error);
        showError(`Search failed: ${error.message}`);
    }
});

// Create a paper card element
function createPaperCard(paper, index) {
    const paperCard = document.createElement('div');
    paperCard.className = 'col-12 mb-4'; // Full width cards
    
    // Add different animation attributes for a more dynamic feel
    const animations = ['fade-up', 'fade-right', 'zoom-in', 'flip-up'];
    const randomAnim = animations[index % animations.length];
    
    paperCard.setAttribute('data-aos', randomAnim);
    paperCard.setAttribute('data-aos-delay', (index * 150).toString());
    paperCard.setAttribute('data-aos-duration', (800 + (index * 50)).toString());
    
    // Handle error case for this specific paper
    if (paper.error) {
        paperCard.innerHTML = `
            <div class="paper-card">
                <div class="paper-header">
                    <div class="paper-index">${index + 1}</div>
                    <h3 class="paper-title">${escapeHTML(paper.title || 'No Title')}</h3>
                    ${paper.link ? `<a href="${escapeHTML(paper.link)}" class="paper-link" target="_blank" rel="noopener noreferrer">
                        <i class="fas fa-external-link-alt"></i> Read Paper
                    </a>` : ''}
                </div>
                <div class="paper-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> ${escapeHTML(paper.error)}
                    </div>
                </div>
            </div>
        `;
        return paperCard;
    }
    
    // Regular paper with content - enhanced layout
    paperCard.innerHTML = `
        <div class="paper-card">
            <div class="paper-header">
                <div class="paper-index">${index + 1}</div>
                <h3 class="paper-title">${escapeHTML(paper.title || 'No Title')}</h3>
                ${paper.link ? `<a href="${escapeHTML(paper.link)}" class="paper-link" target="_blank" rel="noopener noreferrer">
                    <i class="fas fa-external-link-alt"></i> Read Paper
                </a>` : ''}
            </div>
            <div class="paper-body">
                <div class="row">
                    <div class="col-md-7 paper-section">
                        <h4 class="paper-section-title"><i class="fas fa-file-alt me-2"></i>Summary</h4>
                        <p class="paper-summary">${escapeHTML(paper.summary || 'No summary available.')}</p>
                    </div>
                    <div class="col-md-5 paper-section">
                        <h4 class="paper-section-title"><i class="fas fa-balance-scale me-2"></i>Analysis</h4>
                        <div class="advantages-disadvantages">${formatAnalysis(paper.advantages_disadvantages || 'No analysis available.')}</div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    return paperCard;
}

// Format analysis text (preserving line breaks and bullet points)
function formatAnalysis(text) {
    // First escape HTML to prevent XSS
    let safeText = escapeHTML(text);
    
    // Convert line breaks to <br> tags
    safeText = safeText.replace(/\n/g, '<br>');
    
    // Format bullet points (assuming they start with - or *)
    safeText = safeText.replace(/(?:<br>|^)\s*[-*]\s+([^\n<]+)/g, '<br><span class="bullet-point">•</span> $1');
    
    // Format "Advantages:" and "Disadvantages:" as bold with color
    safeText = safeText.replace(/(Advantages):/g, '<span class="advantages-label">$1:</span>');
    safeText = safeText.replace(/(Disadvantages):/g, '<span class="disadvantages-label">$1:</span>');
    
    return safeText;
}

// Show error message
function showError(message) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    
    // Scroll to error
    setTimeout(() => {
        errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
}

// Animate progress bar with smoother animation
function animateProgress() {
    let width = 0;
    progressBar.style.width = '0%';
    
    const interval = setInterval(() => {
        if (width >= 90) {
            clearInterval(interval);
        } else {
            // More natural progression curve
            const increment = 5 + Math.sin(width/10) * 3;
            width += increment;
            if (width > 90) width = 90;
            progressBar.style.width = width + '%';
        }
    }, 400);
    
    // Reset the animation when loading is hidden
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'style' && 
                loadingDiv.style.display === 'none') {
                clearInterval(interval);
                progressBar.style.width = '100%';
                setTimeout(() => {
                    progressBar.style.width = '0%';
                }, 300);
                observer.disconnect();
            }
        });
    });
    
    observer.observe(loadingDiv, { attributes: true });
}

// Add a typing animation effect to the search placeholder
function setupTypingEffect() {
    const placeholders = [
        "Machine Learning",
        "Quantum Computing",
        "Climate Change",
        "Artificial Intelligence",
        "Renewable Energy",
        "Blockchain Technology"
    ];
    
    let currentIndex = 0;
    let currentPlaceholder = "";
    let isDeleting = false;
    let typingSpeed = 100;
    
    function type() {
        const fullText = placeholders[currentIndex];
        
        if (isDeleting) {
            currentPlaceholder = fullText.substring(0, currentPlaceholder.length - 1);
        } else {
            currentPlaceholder = fullText.substring(0, currentPlaceholder.length + 1);
        }
        
        queryInput.setAttribute('placeholder', `E.g., ${currentPlaceholder}...`);
        
        let typeSpeed = isDeleting ? typingSpeed / 2 : typingSpeed;
        
        if (!isDeleting && currentPlaceholder === fullText) {
            typeSpeed = 2000; // Pause at the end
            isDeleting = true;
        } else if (isDeleting && currentPlaceholder === '') {
            isDeleting = false;
            currentIndex = (currentIndex + 1) % placeholders.length;
            typeSpeed = 500; // Pause before typing next word
        }
        
        setTimeout(type, typeSpeed);
    }
    
    setTimeout(type, 1000);
}

// Add parallax scrolling effect to paper cards
function setupParallaxEffect() {
    window.addEventListener('scroll', () => {
        const cards = document.querySelectorAll('.paper-card');
        cards.forEach((card, index) => {
            const scrollPosition = window.scrollY;
            const cardPosition = card.getBoundingClientRect().top + scrollPosition;
            const offset = (scrollPosition - cardPosition) * 0.05;
            
            if (Math.abs(offset) < 20) {
                card.style.transform = `translateY(${offset}px)`;
            }
        });
    });
}

// Add hover effects to paper cards
function setupHoverEffects() {
    document.addEventListener('mousemove', (e) => {
        const cards = document.querySelectorAll('.paper-card');
        cards.forEach(card => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            if (x > 0 && x < rect.width && y > 0 && y < rect.height) {
                const xPercent = x / rect.width;
                const yPercent = y / rect.height;
                const rotateX = (0.5 - yPercent) * 4;
                const rotateY = (xPercent - 0.5) * 4;
                
                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
            } else {
                card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
            }
        });
    });
}

// Basic HTML escaping function to prevent XSS
function escapeHTML(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Initialize all effects when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setupTypingEffect();
    setupParallaxEffect();
    setupHoverEffects();
});